#!/bin/bash

# Remove the user
username=$1
userdel -r $username
