#!/bin/bash
export PATH=$PATH:/data/scripts
/data/scripts/bastionMenu.sh