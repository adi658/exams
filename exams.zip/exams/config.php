<?php
    $DATABASE_SERVER="localhost";
    $DATABASE_PORT="3306";
    $DATABASE_NAME="exams";
    $DATABASE_USERNAME="root";
    $DATABASE_PASSWORD="";

    include ("db.php");
?>