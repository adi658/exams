<html>
	<head>
		<link rel="stylesheet" href="style.css">
		<script src = "main.js"></script>
		<title>Add Question</title>
	</head>
	<body>
		<div class = "mainDiv" align = "center">
			<?php
				include_once("header.php");
			?>
			<table cellspacing = "1px" cellpadding = "5px" border = "1px" width = "100%" class = "mainTable" align = "center" style = "height:70%">
				<tr>
					<td align = "center">
						<img src = "img/ignou.png">
					</td>
				</tr>
			</table>
		</div>
	</body>
</html>